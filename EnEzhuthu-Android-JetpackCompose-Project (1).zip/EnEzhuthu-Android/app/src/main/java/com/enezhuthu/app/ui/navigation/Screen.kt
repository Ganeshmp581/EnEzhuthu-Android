package com.enezhuthu.app.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Explore : Screen("explore")
    object Write : Screen("write")
    object Notifications : Screen("notifications")
    object Profile : Screen("profile")
    object PostDetail : Screen("post/{postId}") {
        fun createRoute(postId: String) = "post/$postId"
    }
}