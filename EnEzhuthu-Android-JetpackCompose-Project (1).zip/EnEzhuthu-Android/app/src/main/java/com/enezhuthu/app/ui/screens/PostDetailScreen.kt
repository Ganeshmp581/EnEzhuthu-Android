package com.enezhuthu.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.enezhuthu.app.data.model.Comment
import com.enezhuthu.app.data.repository.FirebaseRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(postId: String, navController: NavController, repository: FirebaseRepository = remember { FirebaseRepository() }) {
    val comments by repository.getCommentsFlow(postId).collectAsState(initial = emptyList())
    var commentText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("வாசிப்பு களம் (Reader)") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text("வாசகர் கருத்துக்கள் (Comments)", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                }
                items(comments) { comm ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(comm.authorName, style = MaterialTheme.typography.labelMedium)
                            Text(comm.content, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("உங்கள் கருத்தை எழுதுங்கள்…") },
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (commentText.isNotBlank()) {
                            val user = repository.currentUser
                            scope.launch {
                                repository.addComment(
                                    postId,
                                    Comment(
                                        postId = postId,
                                        authorId = user?.uid ?: "user",
                                        authorName = user?.displayName ?: "Reader",
                                        content = commentText.trim(),
                                        createdAt = System.currentTimeMillis().toString()
                                    )
                                )
                                commentText = ""
                            }
                        }
                    }
                ) {
                    Text("அனுப்பு")
                }
            }
        }
    }
}