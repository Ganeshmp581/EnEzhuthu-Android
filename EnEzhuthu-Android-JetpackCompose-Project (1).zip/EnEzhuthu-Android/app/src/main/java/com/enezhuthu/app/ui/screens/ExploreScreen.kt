package com.enezhuthu.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.enezhuthu.app.data.repository.FirebaseRepository
import com.enezhuthu.app.ui.navigation.Screen

@Composable
fun ExploreScreen(navController: NavController, repository: FirebaseRepository = remember { FirebaseRepository() }) {
    var searchQuery by remember { mutableStateOf("") }
    val posts by repository.getPostsFlow().collectAsState(initial = emptyList())

    val filtered = posts.filter {
        it.title.contains(searchQuery, ignoreCase = true) ||
        it.body.contains(searchQuery, ignoreCase = true) ||
        it.authorName.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("தேடுக (Search by title, author...)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { post ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        navController.navigate(Screen.PostDetail.createRoute(post.id))
                    }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(post.title, style = MaterialTheme.typography.titleMedium)
                        Text("By ${post.authorName}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}