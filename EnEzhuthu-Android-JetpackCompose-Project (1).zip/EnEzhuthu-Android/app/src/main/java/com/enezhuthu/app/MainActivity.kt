package com.enezhuthu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.enezhuthu.app.ui.navigation.Screen
import com.enezhuthu.app.ui.navigation.BottomNavigationBar
import com.enezhuthu.app.ui.screens.*
import com.enezhuthu.app.ui.theme.EnEzhuthuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EnEzhuthuTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        if (currentRoute in listOf(
                            Screen.Home.route,
                            Screen.Explore.route,
                            Screen.Notifications.route,
                            Screen.Profile.route
                        )) {
                            BottomNavigationBar(navController = navController)
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Home.route) {
                            HomeScreen(navController = navController)
                        }
                        composable(Screen.Explore.route) {
                            ExploreScreen(navController = navController)
                        }
                        composable(Screen.Write.route) {
                            WriteScreen(navController = navController)
                        }
                        composable(Screen.Notifications.route) {
                            NotificationsScreen(navController = navController)
                        }
                        composable(Screen.Profile.route) {
                            ProfileScreen(navController = navController)
                        }
                        composable(Screen.PostDetail.route) { backStackEntry ->
                            val postId = backStackEntry.arguments?.getString("postId") ?: ""
                            PostDetailScreen(postId = postId, navController = navController)
                        }
                    }
                }
            }
        }
    }
}