package com.enezhuthu.app.data.repository

import com.enezhuthu.app.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    val currentUser get() = auth.currentUser

    fun getPostsFlow(): Flow<List<Post>> = callbackFlow {
        val listener = firestore.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val posts = snapshot?.toObjects(Post::class.java)?.filter { !it.isHidden } ?: emptyList()
                trySend(posts)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createPost(post: Post): String {
        val docRef = firestore.collection("posts").document()
        val postWithId = post.copy(id = docRef.id)
        docRef.set(postWithId).await()
        return docRef.id
    }

    suspend fun deletePost(postId: String) {
        firestore.collection("posts").document(postId).delete().await()
    }

    suspend fun toggleLike(postId: String, userId: String, isLiked: Boolean) {
        val likeRef = firestore.collection("posts").document(postId)
            .collection("likes").document(userId)
        val postRef = firestore.collection("posts").document(postId)

        firestore.runTransaction { transaction ->
            if (isLiked) {
                transaction.delete(likeRef)
                val snapshot = transaction.get(postRef)
                val current = snapshot.getLong("likesCount") ?: 1
                transaction.update(postRef, "likesCount", (current - 1).coerceAtLeast(0))
            } else {
                val data = hashMapOf("userId" to userId, "createdAt" to System.currentTimeMillis().toString())
                transaction.set(likeRef, data)
                val snapshot = transaction.get(postRef)
                val current = snapshot.getLong("likesCount") ?: 0
                transaction.update(postRef, "likesCount", current + 1)
            }
        }.await()
    }

    fun getCommentsFlow(postId: String): Flow<List<Comment>> = callbackFlow {
        val listener = firestore.collection("posts").document(postId)
            .collection("comments")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val comments = snapshot?.toObjects(Comment::class.java) ?: emptyList()
                trySend(comments)
            }
        awaitClose { listener.remove() }
    }

    suspend fun addComment(postId: String, comment: Comment) {
        val commentRef = firestore.collection("posts").document(postId)
            .collection("comments").document()
        commentRef.set(comment.copy(id = commentRef.id)).await()
    }
}