package com.enezhuthu.app

import android.app.Application
import com.google.firebase.FirebaseApp

class EnEzhuthuApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
    }
}