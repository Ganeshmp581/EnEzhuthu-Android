package com.enezhuthu.app.data.model

import com.google.firebase.firestore.DocumentId

enum class Category(val displayName: String) {
    Poetry("கவிதை (Poetry)"),
    Love("காதல் (Love)"),
    Stories("கதைகள் (Stories)"),
    Motivation("ஊக்கம் (Motivation)"),
    PersonalThoughts("சுயசிந்தனை (Thoughts)"),
    Articles("கட்டுரைகள் (Articles)"),
    Society("சமூகம் (Society)"),
    Politics("அரசியல் (Politics)"),
    Other("பிற (Other)")
}

data class Post(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorUsername: String = "",
    val authorPhotoURL: String = "",
    val title: String = "",
    val body: String = "",
    val language: String = "ta",
    val category: String = "Poetry",
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isHidden: Boolean = false,
    val createdAt: String = "",
    val updatedAt: String? = null
)

data class Comment(
    @DocumentId val id: String = "",
    val postId: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorUsername: String = "",
    val authorPhotoURL: String = "",
    val content: String = "",
    val createdAt: String = ""
)

data class UserProfile(
    @DocumentId val id: String = "",
    val email: String = "",
    val username: String = "",
    val displayName: String = "",
    val bio: String = "",
    val photoURL: String = "",
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val role: String = "user"
)