package com.enezhuthu.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun NotificationsScreen(navController: NavController) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("அறிவிப்புகள் (Notifications)", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("என்எழுத்து சமூகத்திற்கு நல்வரவு!", style = MaterialTheme.typography.titleSmall)
                        Text("உங்கள் முதல் கவிதை அல்லது கதையை இன்றே எழுதுங்கள்.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}