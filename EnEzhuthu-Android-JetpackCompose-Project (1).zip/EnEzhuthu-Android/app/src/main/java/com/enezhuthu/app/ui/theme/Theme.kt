package com.enezhuthu.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepNavy = Color(0xFF0B132B)
val MidnightNavy = Color(0xFF1C2541)
val SurfaceNavy = Color(0xFF232F4D)
val AccentGold = Color(0xFFE5A93C)
val AccentGoldLight = Color(0xFFF6C90E)
val TextLight = Color(0xFFF1F5F9)
val TextMuted = Color(0xFF94A3B8)

private val DarkColorScheme = darkColorScheme(
    primary = AccentGold,
    onPrimary = DeepNavy,
    primaryContainer = SurfaceNavy,
    onPrimaryContainer = AccentGoldLight,
    secondary = AccentGoldLight,
    onSecondary = DeepNavy,
    background = DeepNavy,
    onBackground = TextLight,
    surface = MidnightNavy,
    onSurface = TextLight,
    surfaceVariant = SurfaceNavy,
    onSurfaceVariant = TextMuted
)

@Composable
fun EnEzhuthuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),
        content = content
    )
}