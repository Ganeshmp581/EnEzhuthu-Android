package com.enezhuthu.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.enezhuthu.app.data.model.Post
import com.enezhuthu.app.data.repository.FirebaseRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WriteScreen(navController: NavController, repository: FirebaseRepository = remember { FirebaseRepository() }) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Poetry") }
    var language by remember { mutableStateOf("ta") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("புதிய படைப்பு (Write Post)") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("தலைப்பு (Title)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = body,
                onValueChange = { body = it },
                label = { Text("படைப்பு வரிகள் (Content in Tamil/English)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            Button(
                onClick = {
                    if (title.isBlank() || body.isBlank()) {
                        Toast.makeText(context, "Fill in title and content", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val user = repository.currentUser
                    scope.launch {
                        repository.createPost(
                            Post(
                                authorId = user?.uid ?: "anonymous",
                                authorName = user?.displayName ?: "Tamil Writer",
                                authorUsername = user?.email?.substringBefore("@") ?: "writer",
                                title = title.trim(),
                                body = body.trim(),
                                language = language,
                                category = category,
                                createdAt = System.currentTimeMillis().toString()
                            )
                        )
                        Toast.makeText(context, "படைப்பு வெளியானது! (Published)", Toast.LENGTH_SHORT).show()
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("வெளியிடு (Publish)")
            }
        }
    }
}