package com.enezhuthu.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.enezhuthu.app.data.repository.FirebaseRepository
import com.google.firebase.auth.FirebaseAuth

@Composable
fun ProfileScreen(navController: NavController, repository: FirebaseRepository = remember { FirebaseRepository() }) {
    val user = repository.currentUser

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = user?.displayName ?: "எழுத்தாளர் (Author)",
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = user?.email ?: "guest@enezhuthu.app",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = {
                FirebaseAuth.getInstance().signOut()
            }
        ) {
            Text("வெளியேறு (Sign Out)")
        }
    }
}