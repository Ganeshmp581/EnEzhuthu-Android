# En Ezhuthu ProGuard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.google.firebase.firestore.DocumentId *;
    @com.google.firebase.firestore.PropertyName *;
}
